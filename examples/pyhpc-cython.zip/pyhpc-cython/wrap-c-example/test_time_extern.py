

import time_extern

print "Time extern docstring:"
print time_extern.__doc__

print "get_date() docstring:"
print time_extern.get_date.__doc__

print "time_extern.get_date(): ", time_extern.get_date()

int cfib(int n);
